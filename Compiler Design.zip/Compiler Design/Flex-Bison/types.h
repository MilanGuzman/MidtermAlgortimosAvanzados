#ifndef TYPES_H
#define TYPES_H

/* Forward declarations */
struct arst;
struct Ht_item;
struct LinkedList;
struct HashTable;

/* Type aliases */
typedef struct arst       ARST;
typedef struct Ht_item    Ht_item;
typedef struct LinkedList LinkedList;
typedef struct HashTable  HashTable;

#endif /* TYPES_H */

